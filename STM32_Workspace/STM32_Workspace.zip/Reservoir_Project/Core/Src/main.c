/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <string.h>
#include <stdio.h>
uint8_t txd_message_buffer[64] = {0};
uint8_t rpm_tick_count = 0;
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */
uint8_t wall_clock_hr_update_flag = 0;
volatile uint8_t clock_hours = 0;
volatile uint8_t clock_mins = 0;
volatile uint8_t clock_secs = 0;
volatile uint8_t distance = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART6_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
volatile uint8_t hcsr04_Rx_flag = 0;
volatile uint32_t first_edge = 0;
volatile uint32_t time_edge1 = 0;
volatile uint32_t time_edge2 = 0;
volatile uint32_t time_diff = 0;

void ADC_Select_CH(int CH)
{
ADC_ChannelConfTypeDef sConfig = {0};
switch(CH)
{
case 0:
sConfig.Channel = ADC_CHANNEL_0;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 1:
sConfig.Channel = ADC_CHANNEL_1;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 2:
sConfig.Channel = ADC_CHANNEL_2;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 3:
sConfig.Channel = ADC_CHANNEL_3;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 4:
sConfig.Channel = ADC_CHANNEL_4;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 5:
sConfig.Channel = ADC_CHANNEL_5;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 6:
sConfig.Channel = ADC_CHANNEL_6;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 7:
sConfig.Channel = ADC_CHANNEL_7;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 8:
sConfig.Channel = ADC_CHANNEL_8;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 9:
sConfig.Channel = ADC_CHANNEL_9;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 10:
sConfig.Channel = ADC_CHANNEL_10;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 11:
sConfig.Channel = ADC_CHANNEL_11;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 12:
sConfig.Channel = ADC_CHANNEL_12;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 13:
sConfig.Channel = ADC_CHANNEL_13;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 14:
sConfig.Channel = ADC_CHANNEL_14;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
case 15:
sConfig.Channel = ADC_CHANNEL_15;
sConfig.Rank = 1;
if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
{
Error_Handler();
}
break;
}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

	//distance sensor pulse sending
	void HCSR04_TRIG_PULSE(void){
		HAL_GPIO_WritePin(GPIOC, TRIG_PIN_Pin, GPIO_PIN_SET);
		for(int j=0; j!=48; j= j+1){};
		HAL_GPIO_WritePin(GPIOC, TRIG_PIN_Pin, GPIO_PIN_RESET);
		HAL_Delay(30);
	}

	// printing digits A and B
	void DIGITS_Display(uint8_t DIGIT_A, uint8_t DIGIT_B)
		{
			 uint8_t DIGITA_VAL = 0x0F & DIGIT_A; //mask off higher4 bits
			 int Abit0 = (DIGITA_VAL ) & 1;  	// extract Abit0 of the 4-bit value
			 int Abit1 = (DIGITA_VAL >> 1) & 1;  // extract Abit1 of the 4-bit value
			 int Abit2 = (DIGITA_VAL >> 2) & 1;  // extract Abit2 of the 4-bit value
			 int Abit3 = (DIGITA_VAL >> 3) & 1;  // extract Abit3 of the 4-bit value

			 uint8_t DIGITB_VAL = 0x0F & DIGIT_B; //mask off higher4 bits
			 int Bbit0 = (DIGITB_VAL ) & 1;  	// extract Bbit0 of the 4-bit value
			 int Bbit1 = (DIGITB_VAL >> 1) & 1;  // extract Bbit1 of the 4-bit value
			 int Bbit2 = (DIGITB_VAL >> 2) & 1;  // extract Bbit2 of the 4-bit value
			 int Bbit3 = (DIGITB_VAL >> 3) & 1;  // extract Bbit3 of the 4-bit value

			 if (Abit0 == (0))
			 {
				 HAL_GPIO_WritePin(GPIOB, DIGIT_A0_Pin, GPIO_PIN_RESET);
			 }
			 else
			 {
				 HAL_GPIO_WritePin(GPIOB, DIGIT_A0_Pin, GPIO_PIN_SET);
			 }
			 if (Abit1 == (0))
			 {
				 HAL_GPIO_WritePin(GPIOA, DIGIT_A1_Pin, GPIO_PIN_RESET);
			 }
			 else
			 {
				 HAL_GPIO_WritePin(GPIOA, DIGIT_A1_Pin, GPIO_PIN_SET);
			 }
			 if (Abit2 == (0))
			 {
				 HAL_GPIO_WritePin(GPIOA, DIGIT_A2_Pin, GPIO_PIN_RESET);
			 }
			 else
			 {
				 HAL_GPIO_WritePin(GPIOA, DIGIT_A2_Pin, GPIO_PIN_SET);
			 }
			 if (Abit3 == (0))
			 {
				 HAL_GPIO_WritePin(GPIOA, DIGIT_A3_Pin, GPIO_PIN_RESET);
			 }
			 else
			 {
				 HAL_GPIO_WritePin(GPIOA, DIGIT_A3_Pin, GPIO_PIN_SET);
			 }
			 if (Bbit0 == (0))
			 {
				 HAL_GPIO_WritePin(GPIOB, DIGIT_B0_Pin, GPIO_PIN_RESET);
			 }
			 else
			 {
				 HAL_GPIO_WritePin(GPIOB, DIGIT_B0_Pin, GPIO_PIN_SET);
			 }
			 if (Bbit1 == (0))
			 {
				 HAL_GPIO_WritePin(GPIOB, DIGIT_B1_Pin, GPIO_PIN_RESET);
			 }
			 else
			 {
				 HAL_GPIO_WritePin(GPIOB, DIGIT_B1_Pin, GPIO_PIN_SET);

			 }
			 if (Bbit2 == (0))
			 {
				 HAL_GPIO_WritePin(GPIOC, DIGIT_B2_Pin, GPIO_PIN_RESET);
			 }
			 else
			 {
				 HAL_GPIO_WritePin(GPIOC, DIGIT_B2_Pin, GPIO_PIN_SET);
			 }
			 if (Bbit3 == (0))
			 {
				 HAL_GPIO_WritePin(GPIOC, DIGIT_B3_Pin, GPIO_PIN_RESET);
			 }
			 else
			 {
				 HAL_GPIO_WritePin(GPIOC, DIGIT_B3_Pin, GPIO_PIN_SET);
			 }
		}


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  int TIM1_Ch1_DCVAL = 500;
  int TIM1_CH1_STEP = 20;
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_USART6_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim1);
  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);

  TIM1->PSC = 16-1;
  TIM1->ARR = 20000-1;
  TIM1->CCR1 = 00;

  clock_hours = 0;

//  uint8_t timer_ones = timer % 10;
//  uint8_t timer_tens = (timer - timer_ones) / 10;  // separate out digits A and B

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
//  HCSR04_TRIG_PULSE();
  TIM1->CCR1 = 2500;
  HAL_GPIO_WritePin(GPIOA, LD2_Pin, GPIO_PIN_RESET);

 // * SETUP CODE
  // Array to store inputs
    uint8_t setupInputs[17];
    char buffer[2] = {0};

    // Prompt and collect inputs
    sprintf((char*)txd_message_buffer, "\r SETUP MODE \n\n");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_Delay(500);

    sprintf((char*)txd_message_buffer, "\r Enter SETUP Params \n\n");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);

    sprintf((char*)txd_message_buffer, "\r\n Enter FIRST PIPELINE CHOICE FOR CONNECTION (0 for DEMO): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    setupInputs[0] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter FIRST PIPELINE CHOICE FOR MOTOR PWM (0 for DEMO): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    setupInputs[1] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter SECOND ZONE CHOICE FOR CONNECTION (1-3): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    setupInputs[2] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter SECOND ZONE CHOICE FOR MOTOR PWM (1-3): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    setupInputs[3] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter THIRD ZONE CHOICE FOR CONNECTION (1-3): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    setupInputs[4] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter THIRD ZONE CHOICE FOR MOTOR PWM (1-3): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    setupInputs[5] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter FORTH ZONE CHOICE FOR CONNECTION (1-3): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    setupInputs[6] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter FORTH ZONE CHOICE FOR MOTOR PWM (1-3): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 1, HAL_MAX_DELAY);
    setupInputs[7] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter CURRENT WALL CLOCK TIME (00 for DEMO): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[8] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter INLET WALL CLOCK START TIME (00 for DEMO): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[9] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter INLET WALL CLOCK STOP TIME (07 for DEMO): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[10] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter FIRST ZONE CHOICE WALL CLOCK START TIME (08-23): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[11] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter FIRST ZONE CHOICE WALL CLOCK STOP TIME (09-23): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[12] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter SECOND ZONE CHOICE WALL CLOCK START TIME (08-23): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[13] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter SECOND ZONE CHOICE WALL CLOCK STOP TIME (09-23): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[14] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter THIRD ZONE CHOICE WALL CLOCK START TIME (08-23): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[15] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n Enter THIRD ZONE CHOICE WALL CLOCK STOP TIME (09-23): ");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    HAL_UART_Receive(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    HAL_UART_Transmit(&huart6, (uint8_t *)buffer, 2, HAL_MAX_DELAY);
    setupInputs[16] = atoi(buffer);

    sprintf((char*)txd_message_buffer, "\r\n\n Printing Set Up Parameters \n");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);

    sprintf((char*)txd_message_buffer, "\r\n FIRST PIPELINE CHOICE: 0 \t");
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "Pump PWR: %d\t", setupInputs[1]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "FIRST ZONE CHOICE WALL CLOCK START TIME: %d\t", setupInputs[11]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "FIRST ZONE CHOICE WALL CLOCK STOP TIME: %d\t", setupInputs[12]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);

    sprintf((char*)txd_message_buffer, "\r\n SECOND ZONE CHOICE: %d \t", setupInputs[2]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "Pump PWR: %d\t", setupInputs[3]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "SECOND ZONE CHOICE WALL CLOCK START TIME: %d\t", setupInputs[13]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "SECOND ZONE CHOICE WALL CLOCK STOP TIME: %d\t", setupInputs[14]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);

    sprintf((char*)txd_message_buffer, "\r\n THIRD ZONE CHOICE: %d \t", setupInputs[4]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "Pump PWR: %d\t", setupInputs[5]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "THIRD ZONE CHOICE WALL CLOCK START TIME: %d\t", setupInputs[15]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
    sprintf((char*)txd_message_buffer, "THIRD ZONE CHOICE WALL CLOCK STOP TIME: %d\t", setupInputs[16]);
    HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);

    uint8_t percent_full = 0;

	  sprintf((char*)txd_message_buffer, "\r\n\n SETUP is done. Press BLUE BUTTON for RUN MODE. ");
	  HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
	  while(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == 1){
		  HAL_GPIO_WritePin(GPIOA, LD2_Pin, GPIO_PIN_SET);
		  HAL_Delay(50);
		  HAL_GPIO_WritePin(GPIOA, LD2_Pin, GPIO_PIN_RESET);
		  HAL_Delay(50);
		  if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == 0){
			  break;
		  }
	  }

	  HAL_GPIO_WritePin(GPIOA, LD2_Pin, GPIO_PIN_SET);
	  sprintf((char*)txd_message_buffer, "\r\n\n RUN MODE \n\n");
	  HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);

  // RUN MODE CODE WITH TITLES

	  sprintf((char*)txd_message_buffer, "\r WALL CLOCK (hr): | ZONE/INLET: | MOTOR %%PWM: | RPM: | WATER DEPTH (%%): \n");
	  HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);

	  HAL_TIM_Base_Init(&htim3);
	  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);

	  uint8_t PWM_Percent = 0;

	  for (int i = 0; i <= 24; i++){
		  uint8_t zone_number = 100;
		  if (i >= 0 && i < 7){
			  zone_number = 0;
			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, 0);
			  HAL_GPIO_WritePin(GPIOB, RED_Pin, 0);
			  HAL_GPIO_WritePin(GPIOA, GREEN_Pin, 0);

			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, 1);
			  HAL_GPIO_WritePin(GPIOA, RED_Pin, 1);

			  HAL_TIM_Base_Start(&htim1);
			  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
			  TIM1->PSC = 16-1;
			  TIM1->ARR = 20000-1;
			  TIM1->CCR1 = 2500;

			  /*
			   * NOTE: since we set the PWM to be 0 in this case, we should be able to adjust the value of the Motor Speed using the potentiometer
			   */

		  } else if (i >= 7 && i < setupInputs[12]){
			  zone_number = 1;
			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, 0);
			  HAL_GPIO_WritePin(GPIOB, RED_Pin, 0);
			  HAL_GPIO_WritePin(GPIOA, GREEN_Pin, 0);

			  HAL_GPIO_WritePin(GPIOA, RED_Pin, 1);

			  HAL_TIM_Base_Start(&htim1);
			  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
			  TIM1->PSC = 16-1;
			  TIM1->ARR = 20000-1;
			  TIM1->CCR1 = 1834;

			  if (setupInputs[3] == 1){
				  PWM_Percent = 70;
			  } else if (setupInputs[3] == 2){
				  PWM_Percent = 85;
			  } else if (setupInputs[3] == 3){
				  PWM_Percent = 90;
			  }

		  } else if (i >= setupInputs[12] && i < setupInputs[14]){
			  zone_number = 2;
			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, 0);
			  HAL_GPIO_WritePin(GPIOB, RED_Pin, 0);
			  HAL_GPIO_WritePin(GPIOA, GREEN_Pin, 0);

			  HAL_GPIO_WritePin(GPIOA, GREEN_Pin, 1);

			  HAL_TIM_Base_Start(&htim1);
			  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
			  TIM1->PSC = 16-1;
			  TIM1->ARR = 20000-1;
			  TIM1->CCR1 = 1168;

			  if (setupInputs[5] == 1){
				  PWM_Percent = 70;
			  } else if (setupInputs[5] == 2){
				  PWM_Percent = 85;
			  } else if (setupInputs[5] == 3){
				  PWM_Percent = 90;
			  }

		  } else if (i >= setupInputs[14] && i < setupInputs[16]){
			  zone_number = 3;
			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, 0);
			  HAL_GPIO_WritePin(GPIOB, RED_Pin, 0);
			  HAL_GPIO_WritePin(GPIOA, GREEN_Pin, 0);

			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, 1);
			  HAL_TIM_Base_Start(&htim1);
			  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
			  TIM1->PSC = 16-1;
			  TIM1->ARR = 20000-1;
			  TIM1->CCR1 = 500;

			  if (setupInputs[7] == 1){
				  PWM_Percent = 70;
			  } else if (setupInputs[7] == 2){
				  PWM_Percent = 85;
			  } else if (setupInputs[7] == 3){
				  PWM_Percent = 90;
			  }



		  } else if (i >= setupInputs[16]){
			  sprintf((char*)txd_message_buffer, "\r %d| %s| %d| %d| %d\n", i, " " ,PWM_Percent, rpm_tick_count, percent_full);
			  HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
			  PWM_Percent = 0;

			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, GPIO_PIN_RESET);
			  HAL_GPIO_WritePin(GPIOB, RED_Pin, GPIO_PIN_RESET);
			  HAL_GPIO_WritePin(GPIOA, GREEN_Pin, GPIO_PIN_RESET);

			  if (i == 24){
				  sprintf((char*)txd_message_buffer, "Irrigation Complete\r\n");
				  HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
				  break;
			  }
			  HAL_Delay(12000);
		  }



		  // Getting the distance from sensor
//		  hcsr04_Rx_flag = 0;
//		  first_edge = 0;
//		  time_edge1 = 0;
//		  time_edge2 = 0;
//		  time_diff = 0;
//		  distance = 0;
//		  max_depth = 100;
//

//		  HCSR04_TRIG_PULSE();
//		  while(hcsr04_Rx_flag == 0){};
//		  time_diff = time_edge2-time_edge1;
//		  distance = (int)(((float)time_diff)/304);
//		  percent_full = max_depth - distance;


		  // Displaying onto a timer
//		  tens_digit = percent_full % 10;
//		  ones_digit = percent_full - tens_digit * 10;
//		  DIGITS_Display(tens_digit, ones_digit);
//

		  // if the reservoir is empty (below threshold of 20%)
//		  if (percent_full <= 20){
//			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, 0);
//			  HAL_GPIO_WritePin(GPIOB, RED_Pin, 0);
//			  HAL_GPIO_WritePin(GPIOA, GREEN_Pin, 0);
//
//			  HAL_Delay(500);
//
//			  HAL_GPIO_WritePin(GPIOB, BLUE_Pin, 1);
//			  HAL_GPIO_WritePin(GPIOB, RED_Pin, 1);
//			  HAL_GPIO_WritePin(GPIOA, GREEN_Pin, 1);
//
//			  HAL_Delay(500);
//		  }
		  if(i < setupInputs[16]){
			  sprintf((char*)txd_message_buffer, "\r %d| %d| %d| %d| %d\n", i, zone_number,PWM_Percent, rpm_tick_count, percent_full);
			  HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), HAL_MAX_DELAY);
			  HAL_Delay(12000);
		  }
	  }

	  //servo controlling
	  // TIM1->CCR1 = ____________

	  //get pulse width (time_diff) and distance (distance)


	  HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
	  HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_2);

	  // getting the adc value from the potentiometer
	  ADC_Select_CH(9);
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 1000);
	  uint8_t ADC_CH9 = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);
	  // end of potentiometer code

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_8B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 16-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 20000-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 500-1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 16-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 2000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 1200-1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.Pulse = 0;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 9600;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(DIGIT_B3_GPIO_Port, DIGIT_B3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, DIGIT_A3_Pin|DIGIT_A2_Pin|DIGIT_A1_Pin|LD2_Pin
                          |GREEN_Pin|RED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, DIGIT_A0_Pin|DIGIT_B0_Pin|DIGIT_B1_Pin|BLUE_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 TRIG_PIN_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_13|TRIG_PIN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : DIGIT_B3_Pin */
  GPIO_InitStruct.Pin = DIGIT_B3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DIGIT_B3_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DIGIT_A3_Pin DIGIT_A2_Pin DIGIT_A1_Pin LD2_Pin
                           GREEN_Pin RED_Pin */
  GPIO_InitStruct.Pin = DIGIT_A3_Pin|DIGIT_A2_Pin|DIGIT_A1_Pin|LD2_Pin
                          |GREEN_Pin|RED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : DIGIT_A0_Pin DIGIT_B0_Pin DIGIT_B1_Pin BLUE_Pin */
  GPIO_InitStruct.Pin = DIGIT_A0_Pin|DIGIT_B0_Pin|DIGIT_B1_Pin|BLUE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : RPM_TICK_Pin */
  GPIO_InitStruct.Pin = RPM_TICK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(RPM_TICK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DIGIT_B2_Pin */
  GPIO_InitStruct.Pin = DIGIT_B2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DIGIT_B2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim){
	if (htim->Instance == TIM3){
		if (htim->Channel == 1){
			if (first_edge == 0){
				time_edge1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
				first_edge = 1;
			} else {
				time_edge2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
				__HAL_TIM_SET_COUNTER(htim, 0);
				hcsr04_Rx_flag = 1;
			}
		}
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
if((htim->Instance == TIM5))
{
	HAL_UART_Transmit(&huart6, txd_message_buffer, strlen((char*)txd_message_buffer), 1000);
	wall_clock_hr_update_flag = 0; // screen updates occur hourly on the half-hour
	clock_mins += 1;
	if((clock_mins == 60))
	{
		clock_hours += 1;
		clock_mins = 0;
		wall_clock_hr_update_flag = 1; // screen updates occur hourly on the hour
	}
}
}

void HAL_GPIO_EXTI_Callback (uint16_t GPIO_Pin){
	if (GPIO_Pin == RPM_TICK_Pin){				// NOTE THAT RPM CALCULATIONS NEED A CALLBACK
		rpm_tick_count += 1;
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
